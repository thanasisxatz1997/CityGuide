package Panels.Activities;

import javax.swing.*;

public class ActivitiesDisplayPanel extends JPanel {
}
