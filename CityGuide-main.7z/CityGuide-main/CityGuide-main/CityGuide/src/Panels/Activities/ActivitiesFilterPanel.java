package Panels.Activities;

import javax.swing.*;

public class ActivitiesFilterPanel extends JPanel {
}
