package Panels.Activities;

public class ActivitiesSinglePanel {
}
