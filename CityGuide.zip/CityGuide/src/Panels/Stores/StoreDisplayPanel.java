package Panels.Stores;

import javax.swing.*;

public class StoreDisplayPanel extends JPanel {
}
