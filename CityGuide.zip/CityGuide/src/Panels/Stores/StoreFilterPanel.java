package Panels.Stores;

import javax.swing.*;

public class StoreFilterPanel extends JPanel {
}
