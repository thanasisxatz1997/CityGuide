package Panels.Stores;

public class StoresSinglePanel {
}
